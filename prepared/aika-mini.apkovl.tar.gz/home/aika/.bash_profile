[[ -f ~/.bashrc ]] && . ~/.bashrc
