[[ $- == *i* ]] || return
PS1='\[\e[36m\]aika@mini\[\e[0m\]:\w\$ '
alias ls='ls --color=auto'
if [[ -n ${DISPLAY:-} ]]; then fastfetch; fi
if [[ ${AIKA_MINI_WELCOME:-0} == 1 ]]; then
    printf '\nWillkommen auf deiner AikaOS Mini Live-CD!\n\nSuper+Enter: Terminal | Super+E: Dateien | Super+B: Browser\nNetzwerk: Symbol rechts in der Taskleiste\nAenderungen liegen im RAM und gehen beim Neustart verloren.\n\n'
    unset AIKA_MINI_WELCOME
fi
