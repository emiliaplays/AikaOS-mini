export LANG=de_DE.UTF-8
export LANGUAGE=de_DE:de
export TZ=Europe/Berlin
